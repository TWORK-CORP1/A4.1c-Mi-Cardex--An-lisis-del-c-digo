package com.example.micardex

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.micardex.data.Materia
import com.example.micardex.data.PromedioSemestre
import com.example.micardex.ui.CardexViewModel
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CardexApp() } }
    }
}

private fun fmt(d: Double?) = d?.let { String.format(Locale.US, "%.1f", it) } ?: "—"
private fun fmt2(d: Double?) = d?.let { String.format(Locale.US, "%.2f", it) } ?: "—"
private fun calValida(s: String) = s.isBlank() || s.toDoubleOrNull()?.let { it in 0.0..100.0 } == true

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CardexApp(vm: CardexViewModel = viewModel()) {
    val materias by vm.materias.collectAsState()
    val general by vm.promedioGeneral.collectAsState()
    val porSemestre by vm.promediosSemestre.collectAsState()

    var tab by remember { mutableIntStateOf(0) }
    var formVisible by remember { mutableStateOf(false) }
    var editando by remember { mutableStateOf<Materia?>(null) }
    val perfilCompleto = vm.nombre.isNotBlank() && vm.numControl.isNotBlank()

    // Sin sesión iniciada: se muestra solo la pantalla de inicio de sesión
    if (!perfilCompleto) {
        LoginScreen(onEntrar = { n, c -> vm.guardarPerfil(n, c) })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Mi Cardex") })
        },
        floatingActionButton = {
            if (tab == 0) FloatingActionButton(onClick = { editando = null; formVisible = true }) {
                Icon(Icons.Default.Add, contentDescription = "Agregar materia")
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Text(
                "${vm.nombre}  ·  No. control: ${vm.numControl}",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                style = MaterialTheme.typography.bodyMedium
            )
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }) { Text("Materias", Modifier.padding(12.dp)) }
                Tab(selected = tab == 1, onClick = { tab = 1 }) { Text("Promedios", Modifier.padding(12.dp)) }
            }
            if (tab == 0) {
                ListaMaterias(materias, porSemestre,
                    onEditar = { editando = it; formVisible = true },
                    onEliminar = { vm.eliminar(it) })
            } else {
                Promedios(general, porSemestre)
            }
        }
    }

    if (formVisible) {
        MateriaDialog(
            inicial = editando,
            onCancelar = { formVisible = false },
            onGuardar = { vm.guardar(it); formVisible = false }
        )
    }
}

@Composable
fun ListaMaterias(materias: List<Materia>, promedios: List<PromedioSemestre>, onEditar: (Materia) -> Unit, onEliminar: (Materia) -> Unit) {
    if (materias.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Aún no hay materias. Toca + para agregar.")
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        materias.groupBy { it.semestre }.forEach { (sem, lista) ->
            item(key = "sem$sem") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Semestre $sem", style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary)
                    Text("Promedio: ${fmt2(promedios.firstOrNull { it.semestre == sem }?.promedio)}",
                        style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary)
                }
            }
            items(lista, key = { it.id }) { m ->
                Card(Modifier.fillMaxWidth().clickable { onEditar(m) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(m.nombre, fontWeight = FontWeight.Bold)
                            Text(
                                "Normal: ${fmt(m.calNormal)}  ·  Repetición: ${fmt(m.calRepeticion)}  ·  Especial: ${fmt(m.calEspecial)}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text("Final: ${fmt(m.calFinal)}")
                        }
                        IconButton(onClick = { onEliminar(m) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Eliminar")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Promedios(general: Double?, porSemestre: List<PromedioSemestre>) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Promedio general")
                Text(fmt2(general), style = MaterialTheme.typography.headlineLarge)
            }
        }
        Text("Promedio por semestre", style = MaterialTheme.typography.titleMedium)
        if (porSemestre.isEmpty()) Text("Sin calificaciones registradas")
        porSemestre.forEach {
            Card(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Semestre ${it.semestre}")
                    Text(fmt2(it.promedio), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun MateriaDialog(inicial: Materia?, onCancelar: () -> Unit, onGuardar: (Materia) -> Unit) {
    var nombre by remember { mutableStateOf(inicial?.nombre ?: "") }
    var semestre by remember { mutableStateOf(inicial?.semestre?.toString() ?: "") }
    var normal by remember { mutableStateOf(inicial?.calNormal?.toString() ?: "") }
    var repeticion by remember { mutableStateOf(inicial?.calRepeticion?.toString() ?: "") }
    var especial by remember { mutableStateOf(inicial?.calEspecial?.toString() ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    val decimal = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text(if (inicial == null) "Nueva materia" else "Editar materia") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(nombre, { nombre = it }, label = { Text("Nombre de la materia") }, singleLine = true)
                OutlinedTextField(semestre, { semestre = it }, label = { Text("Semestre (1-12)") },
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(normal, { normal = it }, label = { Text("Calificación Normal") },
                    singleLine = true, keyboardOptions = decimal)
                OutlinedTextField(repeticion, { repeticion = it }, label = { Text("Calificación Repetición") },
                    singleLine = true, keyboardOptions = decimal)
                OutlinedTextField(especial, { especial = it }, label = { Text("Calificación Especial") },
                    singleLine = true, keyboardOptions = decimal)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val sem = semestre.toIntOrNull()
                when {
                    nombre.isBlank() -> error = "Escribe el nombre de la materia"
                    sem == null || sem !in 1..12 -> error = "El semestre debe ser de 1 a 12"
                    !calValida(normal) || !calValida(repeticion) || !calValida(especial) ->
                        error = "Las calificaciones deben estar entre 0 y 100"
                    else -> onGuardar(
                        Materia(
                            id = inicial?.id ?: 0, nombre = nombre.trim(), semestre = sem,
                            calNormal = normal.toDoubleOrNull(),
                            calRepeticion = repeticion.toDoubleOrNull(),
                            calEspecial = especial.toDoubleOrNull()
                        )
                    )
                }
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onCancelar) { Text("Cancelar") } }
    )
}

@Composable
fun LoginScreen(onEntrar: (String, String) -> Unit) {
    var nombre by remember { mutableStateOf("") }
    var control by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmar by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Mi Cardex", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Iniciar sesión", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            nombre, { nombre = it; error = null },
            label = { Text("Nombre completo") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            control, { control = it; error = null },
            label = { Text("Número de control") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Una vez que inicies sesión, tu nombre y número de control ya no se podrán modificar.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(16.dp))
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val palabras = nombre.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                when {
                    palabras.size < 2 -> error = "Escribe tu nombre completo (nombre y apellidos)"
                    control.isBlank() -> error = "Escribe tu número de control"
                    else -> confirmar = true
                }
            }
        ) { Text("Iniciar sesión") }
    }

    if (confirmar) {
        val nombreLimpio = nombre.trim().split(Regex("\\s+")).joinToString(" ")
        AlertDialog(
            onDismissRequest = { confirmar = false },
            title = { Text("¿Confirmar datos?") },
            text = { Text("$nombreLimpio\nNo. control: ${control.trim()}\n\nNo podrás modificarlos después.") },
            confirmButton = { TextButton(onClick = { onEntrar(nombreLimpio, control.trim()) }) { Text("Sí, entrar") } },
            dismissButton = { TextButton(onClick = { confirmar = false }) { Text("Revisar") } }
        )
    }
}

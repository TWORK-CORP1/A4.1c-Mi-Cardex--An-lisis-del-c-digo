package com.example.micardex.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.micardex.data.AppDatabase
import com.example.micardex.data.Materia
import com.example.micardex.data.MateriaRepository
import com.example.micardex.data.PerfilStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CardexViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = MateriaRepository(AppDatabase.get(app).materiaDao())
    private val perfil = PerfilStore(app)

    var nombre by mutableStateOf(perfil.nombre)
        private set
    var numControl by mutableStateOf(perfil.numControl)
        private set

    val materias = repo.materias
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val promedioGeneral = repo.promedioGeneral
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val promediosSemestre = repo.promediosPorSemestre
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun guardarPerfil(n: String, c: String) {
        if (nombre.isNotBlank() && numControl.isNotBlank()) return   // ya registrado: no se modifica
        perfil.nombre = n; perfil.numControl = c
        nombre = n; numControl = c
    }

    fun guardar(m: Materia) = viewModelScope.launch {
        repo.guardar(m)
    }

    fun eliminar(m: Materia) = viewModelScope.launch { repo.eliminar(m) }
}

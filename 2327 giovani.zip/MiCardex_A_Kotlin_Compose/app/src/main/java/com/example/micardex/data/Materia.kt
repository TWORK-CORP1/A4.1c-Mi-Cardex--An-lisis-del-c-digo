package com.example.micardex.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Única tabla de la base de datos: una fila por materia. */
@Entity(tableName = "materias")
data class Materia(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String,
    val semestre: Int,
    val calNormal: Double? = null,
    val calRepeticion: Double? = null,
    val calEspecial: Double? = null
) {
    /** Calificación vigente: la de la última oportunidad registrada. */
    val calFinal: Double? get() = calEspecial ?: calRepeticion ?: calNormal
}

/** Resultado de la consulta de promedio por semestre. */
data class PromedioSemestre(val semestre: Int, val promedio: Double)

package com.example.micardex.data

import android.content.Context

/** Guarda de forma permanente el nombre y número de control con SharedPreferences. */
class PerfilStore(context: Context) {
    private val prefs = context.getSharedPreferences("perfil_alumno", Context.MODE_PRIVATE)

    var nombre: String
        get() = prefs.getString("nombre", "") ?: ""
        set(v) = prefs.edit().putString("nombre", v).apply()

    var numControl: String
        get() = prefs.getString("num_control", "") ?: ""
        set(v) = prefs.edit().putString("num_control", v).apply()
}

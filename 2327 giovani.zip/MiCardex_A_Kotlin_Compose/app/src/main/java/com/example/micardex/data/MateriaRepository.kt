package com.example.micardex.data

import kotlinx.coroutines.flow.Flow

/** Intermediario entre el ViewModel y el DAO: el ViewModel nunca toca la base de datos directamente. */
class MateriaRepository(private val dao: MateriaDao) {

    val materias: Flow<List<Materia>> = dao.todas()
    val promedioGeneral: Flow<Double?> = dao.promedioGeneral()
    val promediosPorSemestre: Flow<List<PromedioSemestre>> = dao.promediosPorSemestre()

    /** Si la materia es nueva (id = 0) la inserta; si ya existe, la actualiza. */
    suspend fun guardar(m: Materia) {
        if (m.id == 0) dao.insertar(m) else dao.actualizar(m)
    }

    suspend fun eliminar(m: Materia) = dao.eliminar(m)
}

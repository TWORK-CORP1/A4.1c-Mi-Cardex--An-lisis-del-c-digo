package com.example.micardex.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MateriaDao {
    @Query("SELECT * FROM materias ORDER BY semestre, nombre")
    fun todas(): Flow<List<Materia>>

    @Insert suspend fun insertar(m: Materia)
    @Update suspend fun actualizar(m: Materia)
    @Delete suspend fun eliminar(m: Materia)

    // AVG ignora los NULL, así que las materias sin calificación no cuentan
    @Query("SELECT AVG(COALESCE(calEspecial, calRepeticion, calNormal)) FROM materias")
    fun promedioGeneral(): Flow<Double?>

    @Query(
        """SELECT semestre, AVG(COALESCE(calEspecial, calRepeticion, calNormal)) AS promedio
           FROM materias
           WHERE COALESCE(calEspecial, calRepeticion, calNormal) IS NOT NULL
           GROUP BY semestre ORDER BY semestre"""
    )
    fun promediosPorSemestre(): Flow<List<PromedioSemestre>>
}
